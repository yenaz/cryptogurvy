@extends($activeTemplate.'layouts.frontend')
@section('content')

    @include($activeTemplate.'partials.breadcrumb')

    <section class="pt-120 pb-120 section--bg">
        <div class="container">

            <div class="row">
                <div class="col-lg-12">

                    <ul class="nav nav-tabs custom--style-two nav-tabs--lg justify-content-center  bg-transparent" id="myTab" role="tablist">

                        <li class="nav-item" role="presentation">
                            <a class="nav-link  active" data-toggle="tab" href="#all" >@lang('All') <br> @lang('Wallets')</a>
                        </li>
                        @foreach ($wallets as $item)

                            <li class="nav-item" role="presentation">
                                <a class="nav-link" data-toggle="tab" href="#{{$item->crypto->code}}" >{{__($item->crypto->code)}} ( {{ $cryptoWallets->where('crypto_id',$item->crypto_id)->count()}} ) <br>
                                    {{showAmount($item->balance,8)}}
                                </a>
                            </li>
                            {{$item->code}}
                        @endforeach
                    </ul>

                    <div class="tab-content mt-4" id="myTabContent">
                        <div class="tab-pane fade bg-transparent text-dark  show active " id="all">
                            <div class="custom--card">
                                <div class="card-body p-0">
                                    <div class="table-responsive--lg">
                                        <table class="table custom--table">
                                            <thead>
                                                <tr>
                                                    <th>@lang('Currency')</th>
                                                    <th>@lang('Generated at')</th>
                                                    <th>@lang('Wallet Address')</th>
                                                    <th>@lang('Action')</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @forelse ($cryptoWallets as $wallet)
                                                    <tr>
                                                        <td data-label="@lang('Currency')">{{$wallet->crypto->code}}</td>
                                                        <td data-label="@lang('Generated at')">{{showDateTime($wallet->created_at)}}</b></td>
                                                        <td data-label="@lang('Wallet Address')">{{$wallet->wallet_address}}</td>
                                                        <td data-label="@lang('Action')"><a href="javascript:void(0)" class="cmn-btn btn-sm copy-address" data-clipboard-text="{{$wallet->wallet_address}}"><i class="las la-copy"></i>@lang('Copy Address')</a></td>
                                                    </tr>
                                                @empty
                                                    <tr>
                                                        <td colspan="100%" class="text-center">@lang('No Wallet Yet!')</td>
                                                    </tr>
                                                @endforelse
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>

                        @foreach ($wallets as $item)

                            <div class="tab-pane fade bg-transparent text-dark" id="{{$item->crypto->code}}">

                                <div class="row mt-2">
                                    <div class="col-md-12 text-center">
                                        <h4>@lang('Deposit Charge is') @if($item->crypto->dc_fixed > 0) {{$item->crypto->dc_fixed}} {{$item->crypto->code}} +  @endif {{$item->crypto->dc_percent}}%</h4>
                                    </div>
                                </div>

                                <div class="row mb-3 mt-2">
                                    <div class="col-md-12 d-flex flex-wrap  justify-content-center">

                                        <a href="{{route('user.wallets.generate',$item->crypto->code)}}" class="link-btn m-2"><i class="las la-plus"></i> @lang('Generate New') {{$item->crypto->code}} @lang('Address')</a>

                                        <a href="{{route('user.withdraw',$item->crypto->code)}}" class="link-btn m-2"><i class="las la-credit-card"></i> @lang('Withdraw') {{$item->crypto->code}}</a>

                                    </div>
                                </div>

                                <div class="custom--card">
                                    <div class="card-body p-0">
                                        <div class="table-responsive--lg">
                                            <table class="table custom--table">
                                            <thead>
                                                <tr>
                                                    <th>@lang('Currency')</th>
                                                    <th>@lang('Generated at')</th>
                                                    <th>@lang('Wallet Address')</th>
                                                    <th>@lang('Action')</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @forelse ($cryptoWallets->where('crypto_id',$item->crypto_id) as $wallet)
                                                    <tr>
                                                        <td data-label="@lang('Currency')">{{$wallet->crypto->code}}</td>
                                                        <td data-label="@lang('Generated at')">{{showDateTime($wallet->created_at)}}</b></td>
                                                        <td data-label="@lang('Wallet Address')" id="address-{{$wallet->id}}">{{$wallet->wallet_address}}</td>
                                                        <td data-label="@lang('Action')"><a href="javascript:void(0)" class="cmn-btn btn-sm copy-address" data-clipboard-text="{{$wallet->wallet_address}}"><i class="las la-copy"></i>@lang('Copy Address')</a></td>
                                                    </tr>
                                                @empty
                                                    <tr>
                                                        <td colspan="100%" class="text-center">@lang('No Wallet Yet!')</td>
                                                    </tr>
                                                @endforelse
                                            </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection

@push('script-lib')
    <script src="{{asset($activeTemplateTrue.'js/clipboard.min.js')}}"></script>
@endpush

@push('script')
    <script>
        (function($){
            "use strict";

            $('.copy-address').on('click',function () {
                var clipboard = new ClipboardJS('.copy-address');
                notify('success','Copied : '+$(this).data('clipboard-text'))
            })
        })(jQuery);
    </script>
@endpush
