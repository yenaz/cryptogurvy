@extends($activeTemplate.'layouts.frontend')
@section('content')

    @include($activeTemplate.'partials.breadcrumb')

    <section class="pt-120 pb-120 section--bg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">

                    <ul class="nav nav-tabs custom--style-two justify-content-center  bg-transparent" id="myTab" role="tablist">

                        <li class="nav-item" role="presentation">
                            <a class="nav-link  active" data-toggle="tab" href="#all" >@lang('All')</a>
                        </li>
                        @foreach ($cryptos as $item)
                            <li class="nav-item" role="presentation">
                                <a class="nav-link" data-toggle="tab" href="#{{$item->code}}" >{{__($item->code)}}</a>
                            </li>
                        @endforeach
                    </ul>

                    <div class="tab-content mt-4" id="myTabContent">
                        <div class="tab-pane fade bg-transparent text-dark  show active " id="all">
                            <div class="custom--card">
                                <div class="card-body p-0">
                                    <div class="table-responsive--lg">
                                        <table class="table custom--table">
                                            <thead>
                                                <tr>
                                                    <th>@lang('Crypto Currency')</th>
                                                    <th>@lang('Transaction Code')</th>
                                                    <th>@lang('Amount')</th>
                                                    <th>@lang('Charge')</th>
                                                    <th>@lang('Post balance')</th>
                                                    <th>@lang('Type')</th>
                                                    <th>@lang('Details')</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @forelse ($transactions as $item)
                                                    <tr>
                                                        <td data-label="@lang('Crypto Currency')"><span class="text--base">{{__($item->crypto->code)}}</span></td>
                                                        <td data-label="@lang('Transaction Code')">{{$item->trx}}</td>
                                                        <td data-label="@lang('Amount')">{{showAmount($item->amount,8)}} {{$item->crypto->code}}</td>
                                                        <td data-label="@lang('Charge')">{{showAmount($item->amount,2)}}</td>
                                                        <td data-label="@lang('Post balance')">{{showAmount($item->post_balance,8)}} {{__($item->crypto->code)}}</td>
                                                        <td data-label="@lang('Type')">{{$item->trx_type}}</td>
                                                        <td data-label="@lang('Details')">{{__($item->details)}}</td>
                                                    </tr>
                                                @empty
                                                    <tr>
                                                        <td colspan="100%" class="text-center">{{__($emptyMessage)}}</td>
                                                    </tr>
                                                @endforelse
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>

                        @foreach ($cryptos as $item)
                            <div class="tab-pane fade bg-transparent text-dark" id="{{$item->code}}">
                                <div class="custom--card">
                                    <div class="card-body p-0">
                                        <div class="table-responsive--lg">
                                            <table class="table custom--table">
                                                <thead>
                                                    <tr>
                                                        <th>@lang('Crypto Currency')</th>
                                                        <th>@lang('Transaction Code')</th>
                                                        <th>@lang('Amount')</th>
                                                        <th>@lang('Charge')</th>
                                                        <th>@lang('Post balance')</th>
                                                        <th>@lang('Type')</th>
                                                        <th>@lang('Details')</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @forelse ($transactions->where('crypto_id', $item->id) as $item)
                                                        <tr>
                                                            <td data-label="@lang('Crypto Currency')"><span class="text--base">{{__($item->crypto->code)}}</span></td>
                                                            <td data-label="@lang('Transaction Code')">{{$item->trx}}</td>
                                                            <td data-label="@lang('Amount')">{{showAmount($item->amount,8)}} {{$item->crypto->code}}</td>
                                                            <td data-label="@lang('Charge')">{{showAmount($item->amount,2)}}</td>
                                                            <td data-label="@lang('Post balance')">{{showAmount($item->post_balance,8)}} {{__($item->crypto->code)}}</td>
                                                            <td data-label="@lang('Type')">{{$item->trx_type}}</td>
                                                            <td data-label="@lang('Details')">{{__($item->details)}}</td>
                                                        </tr>
                                                    @empty
                                                        <tr>
                                                            <td colspan="100%" class="text-center">{{__($emptyMessage)}}</td>
                                                        </tr>
                                                    @endforelse
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>

    </section>

@endsection
