@extends($activeTemplate.'layouts.frontend')
@section('content')
    @include($activeTemplate.'partials.breadcrumb')

    <section class="pt-120 pb-120">
        <div class="container">
            <div class="row mb-none-30">
                <div class="col-xl-12 col-lg-12 col-sm-12 mb-30 text-center">
                    <div class="tab-menu">
                        @foreach ($wallets as $item)
                            <a href="{{route('user.transactions',$item->id)}}" class="tab-menu-btn @if($wallet->crypto_id == $item->crypto_id) active @endif">{{__($item->crypto->code)}}</a>
                        @endforeach
                    </div>
                </div>
            </div>
            <div class="row mt-4">
                <div class="col-xl-12">
                    <div class="custom--card">
                        <div class="card-body p-0">
                            <div class="table-responsive--lg">
                                <table class="table custom--table">
                                    <thead>
                                        <tr>
                                            <th>@lang('Crypto Currency')</th>
                                            <th>@lang('Transaction Code')</th>
                                            <th>@lang('Amount')</th>
                                            <th>@lang('Charge')</th>
                                            <th>@lang('Post balance')</th>
                                            <th>@lang('Type')</th>
                                            <th>@lang('Details')</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @forelse ($transactions as $item)

                                            <tr>
                                                <td data-label="@lang('Crypto Currency')"><span class="text--base">{{__($item->crypto->code)}}</span></td>
                                                <td data-label="@lang('Transaction Code')">{{$item->trx}}</td>
                                                <td data-label="@lang('Amount')">{{showAmount($item->amount,8)}} {{__($item->crypto->code)}}</td>
                                                <td data-label="@lang('Charge')">{{showAmount($item->amount,2)}}</td>
                                                <td data-label="@lang('Post balance')">{{showAmount($item->post_balance,8)}} {{__($item->crypto->code)}}</td>
                                                <td data-label="@lang('Type')">{{$item->trx_type}}</td>
                                                <td data-label="@lang('Details')">{{__($item->details)}}</td>
                                            </tr>
                                        @empty
                                            <tr>
                                                <td colspan="100%" class="text-center">{{__($emptyMessage)}}</td>
                                            </tr>
                                        @endforelse

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    {{$transactions->links()}}
                </div>
            </div>
        </div>
    </section>
@endsection
