@extends($activeTemplate.'layouts.frontend')
@section('content')
    @include($activeTemplate.'partials.breadcrumb')

    <section class="pt-120 pb-120">
        <div class="container">
          <div class="row">
            <div class="col-xl-12 col-lg-12 col-sm-12">
                <div class="btn-group justify-content-end">
                    <a href="{{route('user.advertisement.new')}}" class="cmn-btn2 btn-md">@lang('New Advertisement')</a>
                </div>
            </div>
          </div>

          <div class="row mt-4">
            <div class="col-xl-12">
              <div class="custom--card">
                <div class="card-body p-0">
                  <div class="table-responsive--md">
                    <table class="table custom--table">
                      <thead>
                        <tr>
                          <th>@lang('Type')</th>
                          <th>@lang('Currency')</th>
                          <th>@lang('Payment Method')</th>
                          <th>@lang('Margin')</th>
                          <th>@lang('Rate')</th>
                          <th>@lang('Payment Window')</th>
                          <th>@lang('Status')</th>
                          <th>@lang('Action')</th>
                        </tr>
                      </thead>
                      <tbody>
                          @forelse ($advertisements as $item)
                            <tr>
                                <td data-label="@lang('Type')">
                                    @if ($item->type == 1)
                                        <span class="badge text-white badge--released">@lang('Buy')</span>
                                    @elseif($item->type == 2)
                                        <span class="badge text-white badge--fund">@lang('Sell')</span>
                                    @else
                                    @endif
                                </td>
                                <td data-label="@lang('Currency')">{{__($item->fiat->code)}}</td>
                                <td data-label="@lang('Payment Method')">{{__($item->fiatGateway->name)}}</b></td>
                                <td data-label="@lang('Margin')">{{$item->margin}} %</td>
                                <td data-label="@lang('Rate')">{{rate($item->type, $item->crypto->rate, $item->fiat->rate, $item->margin)}} {{__($item->fiat->code)}}/ {{__($item->crypto->code)}}</td>
                                <td data-label="@lang('Payment Window')">{{$item->window}} @lang('Minutes')</td>
                                <td data-label="@lang('Status')">
                                    @if ($item->status == 1)
                                        <span class="badge text-white badge--released">@lang('Active')</span>
                                    @else
                                        <span class="badge text-white badge--cancel">@lang('Deactive')</span>
                                    @endif
                                </td>
                                <td data-label="@lang('Action')"><a href="{{route('user.advertisement.edit',$item->id)}}" class="cmn-btn btn-sm"><i class="las la-edit"></i></a></td>
                            </tr>
                          @empty
                            <tr>
                                <td colspan="100%" class="text-center">{{__($emptyMessage)}}</td>
                            </tr>
                          @endforelse

                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

              {{$advertisements->links()}}
            </div>
          </div>
        </div>
    </section>
@endsection
