<div class="alert alert-warning" role="alert">
    <p class="text-md">@lang('Buy') {{__($tradeRequestsDetails->crypto->name)}} @lang('using') {{__($tradeRequestsDetails->fiatGateway->name)}} @lang('with') {{__($tradeRequestsDetails->fiat->name)}} ({{__($tradeRequestsDetails->fiat->code)}}). {{__($general->sitename)}} @lang('user named') {{__($tradeRequestsDetails->seller->fullname)}} @lang('wishes to sell') {{__($tradeRequestsDetails->crypto->name)}} @lang('to you')</p>
</div>

<h6>@lang('Please make a payment of') {{showAmount($tradeRequestsDetails->amount)}} {{__($tradeRequestsDetails->fiat->code)}} @lang('using') {{__($tradeRequestsDetails->fiatGateway->name)}} @lang('E-Wallet')</h6>

<p class="text-md mt-2">@lang('Once you confirmed your payment to seller') <span class="badge text-white badge--released">{{showAmount($tradeRequestsDetails->crypto_amount,8)}}</span> {{__($tradeRequestsDetails->advertisement->crypto->code)}}  @lang('will be released')</p>

<hr>

<div class="accordion cmn-accordion accordion-arrow" id="accordionExample">
    <div class="card">
        <div class="card-header" id="headingOne">
        <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
            <i class="las la-question-circle"></i>
            <h6>@lang('Trade Information')</h6>
        </button>
        </div>

        <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
        <div class="card-body">
            <ul class="caption-list">
                <li>
                    <span class="caption">@lang('Buyer Name')</span>
                    <span class="value">{{__($tradeRequestsDetails->buyer->fullname)}}</span>
                </li>
                <li>
                    <span class="caption">@lang('Seller Name')</span>
                    <span class="value">{{__($tradeRequestsDetails->seller->fullname)}}</span>
                </li>
                <li>
                    <span class="caption">@lang('Amount')</span>
                    <span class="value">{{showAmount($tradeRequestsDetails->amount)}} {{__($tradeRequestsDetails->fiat->code)}}</span>
                </li>
                <li>
                    <span class="caption">{{__($tradeRequestsDetails->crypto->code)}}</span>
                    <span class="value">{{showAmount($tradeRequestsDetails->crypto_amount,8)}}</span>
                </li>
                <li>
                    <span class="caption">@lang('Payment Window')</span>
                    <span class="value">{{$tradeRequestsDetails->window}} @lang('Minutes')</span>
                </li>
                <li>
                    <span class="caption">@lang('Status')</span>
                    <p class="value">
                        @if ($tradeRequestsDetails->status == 0)
                            <span class="badge text-white badge--pending">@lang('Escrow Funded')</span>
                        @elseif($tradeRequestsDetails->status == 2)
                            <span class="badge text-white badge--paid">@lang('Buyer Paid')</span>
                        @elseif($tradeRequestsDetails->status == 9)
                            <span class="badge text-white badge--cancel">@lang('Canceled')</span>
                        @elseif($tradeRequestsDetails->status == 8)
                            <span class="badge text-white badge--reported">@lang('Reported')</span>
                        @elseif($tradeRequestsDetails->status == 1)
                            <span class="badge text-white badge--completed">@lang('completed')</span>
                        @endif
                    </p>
                </li>
            </ul>
        </div>
        </div>
    </div><!-- card end -->
</div>
<hr>

@if ($tradeRequestsDetails->status == 0)
    @php
        $endTime = $tradeRequestsDetails->created_at->addMinutes($tradeRequestsDetails->window);
        $remainingMinitues = $endTime->diffInMinutes(Carbon\Carbon::now());
    @endphp

    @if ($endTime > Carbon\Carbon::now())
        <div class="alert alert-warning" role="alert">
            <p class="text-md">@lang('The seller can cancel this trade after') {{$remainingMinitues}} @lang('minutes. Please make the payment within that time and mark the payment as paid.')</p>
        </div>
    @else
        <div class="alert alert-warning" role="alert">
            <p class="text-md">@lang('The seller can cancel this trade anytime. Please make the payment and mark the payment as paid.')</p>
        </div>
    @endif

    <hr>

    <div class="row mt-4">
        <div class="col-md-6">
            <form action="{{route('user.trade.request.paid')}}" method="post">
                @csrf
                <input type="hidden" name="id" value="{{$tradeRequestsDetails->id}}">
                <button type="submit" class="cmn-btn bg--success w-100">@lang('I Have Paid') <i class="las la-check"></i>
                </button>
            </form>
        </div>
        <div class="col-md-6 mt-md-0 mt-3">
            <form action="{{route('user.trade.request.cancel')}}" method="POST">
                @csrf
                <input type="hidden" name="id" value="{{$tradeRequestsDetails->id}}">
                <button type="submit" class="cmn-btn btn--danger w-100">@lang('Cancel') <i class="las la-times"></i></button>
            </form>
        </div>
    </div>

    <hr>
@endif

@if ($tradeRequestsDetails->status == 2)

    @php
        $lastTime = Carbon\Carbon::parse($tradeRequestsDetails->paid_at)->addMinutes($tradeRequestsDetails->window);
        $remainingMin = $lastTime->diffInMinutes(Carbon\Carbon::now());
    @endphp

    @if ($lastTime > Carbon\Carbon::now())
        <div class="alert alert-warning" role="alert">
            <p class="text-md">@lang('You can dispute this trade after') {{$remainingMin}} @lang('minutes.')</p>
        </div>
        <hr>
    @endif

    @if ($lastTime <= Carbon\Carbon::now())

        <div class="row mt-4">
            <div class="col-xl-12">
                <form class="mt-3" action="{{route('user.trade.request.dispute')}}" method="post">
                    @csrf
                    <input type="hidden" name="id" value="{{$tradeRequestsDetails->id}}">
                    <button type="submmit" class="cmn-btn btn--danger w-100">@lang('Dispute') <i class="las la-times"></i></button>
                </form>
            </div>
        </div>
        <hr>
    @endif
@endif


